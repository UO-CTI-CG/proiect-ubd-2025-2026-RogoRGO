import sqlite3

conn = sqlite3.connect('hala.db')
c = conn.cursor()

# Tabel materiale
c.execute('''CREATE TABLE IF NOT EXISTS materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    finish TEXT,
    color TEXT,
    thickness TEXT,
    stock INTEGER DEFAULT 0,
    unit TEXT DEFAULT 'buc',
    notes TEXT
)''')

# Tabela rapoarte
c.execute('''
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    date TEXT NOT NULL,
    start_hour TEXT,
    end_hour TEXT,
    location TEXT,
    description TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)
''')

# Tabel utilizatori
c.execute('''CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)''')

# Adaugă coloana avatar dacă nu există deja
try:
    c.execute("ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT 'default.png'")
except:
    pass

# Tabel permisiuni
c.execute('''CREATE TABLE IF NOT EXISTS permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT
)''')

# Tabel legatura rol-permisiune
c.execute('''CREATE TABLE IF NOT EXISTS role_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,
    permission_id INTEGER NOT NULL,
    FOREIGN KEY (permission_id) REFERENCES permissions(id)
)
''')

# Lista permisiuni
permissions = [
    ('view_stock', 'Poate vedea lista de stocuri'),
    ('edit_stock', 'Poate edita stocuri'),
    ('delete_stock', 'Poate sterge stocuri'),
    ('manage_users', 'Poate gestiona utilizatori'),
    ('view_reports', 'Poate vedea rapoarte'),
    ('edit_settings', 'Poate modifica setari aplicatie'),
]

c.executemany('INSERT OR IGNORE INTO permissions (name, description) VALUES (?, ?)', permissions)

# Admin implicit
c.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)",
          ("admin", "admin", "admin"))

# Asociem toate permisiunile cu admin
c.execute('SELECT id FROM permissions')
all_permissions = [row[0] for row in c.fetchall()]
for perm_id in all_permissions:
    c.execute('INSERT OR IGNORE INTO role_permissions (role, permission_id) VALUES (?, ?)',
              ('admin', perm_id))

conn.commit()
conn.close()

print("Baza de date este pregătită (fără pierdere de date).")