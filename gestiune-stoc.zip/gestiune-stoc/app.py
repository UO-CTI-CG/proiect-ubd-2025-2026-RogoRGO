from flask import Flask, render_template, request, redirect, session, url_for
from functools import wraps
import sqlite3
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'cheie_lunga_random_de_64_caractere'

# ===========================
# CONFIG UPLOAD AVATAR
# ===========================

UPLOAD_FOLDER = "static/avatars"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# ===========================
# DECORATORI
# ===========================

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapped


def role_required(required_role):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if 'user' not in session:
                return redirect(url_for('login'))

            conn = sqlite3.connect('hala.db')
            c = conn.cursor()
            c.execute("SELECT role FROM users WHERE username=?", (session['user'],))
            row = c.fetchone()
            conn.close()

            if not row or row[0] != required_role:
                return "Acces interzis! Nu ai permisiunea necesara.", 403

            return f(*args, **kwargs)
        return wrapped
    return decorator


# ===========================
# DEZACTIVARE CACHE
# ===========================

@app.after_request
def add_no_cache_headers(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0, private'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


# ===========================
# LOGIN
# ===========================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':

        username = request.form.get('username', '')
        password = request.form.get('password', '')

        conn = sqlite3.connect('hala.db')
        c = conn.cursor()
        c.execute("SELECT id, password, role FROM users WHERE username=?", (username,))
        row = c.fetchone()
        conn.close()

        if row and row[1] == password:
            session.clear()
            session['user'] = username
            session['user_id'] = row[0]
            session['role'] = row[2]
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Credentiale invalide')

    return render_template('login.html')


# ===========================
# DASHBOARD
# ===========================

@app.route('/')
@login_required
def index():
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()
    c.execute("SELECT id, category, finish, color, thickness, stock, unit, notes FROM materials")
    materials = [
        dict(id=row[0], category=row[1], finish=row[2], color=row[3],
             thickness=row[4], stock=row[5], unit=row[6], notes=row[7])
        for row in c.fetchall()
    ]
    conn.close()
    return render_template('index.html', materials=materials, role=session.get('role', 'user'))


# ===========================
# ADAUGARE MATERIAL (ADMIN)
# ===========================

@app.route('/add', methods=['POST'])
@login_required
@role_required('admin')
def add_material():
    category = request.form['category']
    finish = request.form['finish']
    color = request.form['color']
    thickness = request.form['thickness']
    stock = request.form['stock']
    unit = request.form['unit']
    notes = request.form['notes']

    conn = sqlite3.connect('hala.db')
    c = conn.cursor()
    c.execute('''INSERT INTO materials 
                 (category, finish, color, thickness, stock, unit, notes)
                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
              (category, finish, color, thickness, stock, unit, notes))
    conn.commit()
    conn.close()

    return redirect('/')


# ===========================
# EDITARE MATERIAL (ADMIN)
# ===========================

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def edit_material(id):
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()

    if request.method == 'POST':
        category = request.form['category']
        finish = request.form['finish']
        color = request.form['color']
        thickness = request.form['thickness']
        stock = request.form['stock']
        unit = request.form['unit']
        notes = request.form['notes']

        c.execute('''UPDATE materials 
                     SET category=?, finish=?, color=?, thickness=?, stock=?, unit=?, notes=?
                     WHERE id=?''',
                  (category, finish, color, thickness, stock, unit, notes, id))
        conn.commit()
        conn.close()

        return redirect('/')

    else:
        c.execute("SELECT * FROM materials WHERE id=?", (id,))
        mat = c.fetchone()
        conn.close()

        if mat:
            material = dict(id=mat[0], category=mat[1], finish=mat[2], color=mat[3],
                            thickness=mat[4], stock=mat[5], unit=mat[6], notes=mat[7])
            return render_template('edit.html', material=material)

        return "Materialul nu exista!"


# ===========================
# STERGERE MATERIAL (ADMIN)
# ===========================

@app.route('/delete/<int:id>')
@login_required
@role_required('admin')
def delete_material(id):
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()
    c.execute("DELETE FROM materials WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/')


# ===========================
# GESTIONARE UTILIZATORI (ADMIN)
# ===========================

@app.route('/users')
@login_required
@role_required('admin')
def manage_users():
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()
    c.execute("SELECT id, username, role FROM users")
    users = c.fetchall()
    conn.close()

    return render_template('users.html', users=users)


@app.route('/add_user', methods=['POST'])
@login_required
@role_required('admin')
def add_user():
    username = request.form['username']
    password = request.form['password']
    role = request.form['role']

    conn = sqlite3.connect('hala.db')
    c = conn.cursor()

    try:
        c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                  (username, password, role))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return "Eroare: acest username exista deja!"

    conn.close()
    return redirect(url_for('manage_users'))


@app.route('/delete_user/<int:id>')
@login_required
@role_required('admin')
def delete_user(id):
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('manage_users'))


@app.route('/edit_user/<int:id>', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def edit_user(id):
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        c.execute("UPDATE users SET username=?, password=?, role=? WHERE id=?",
                  (username, password, role, id))
        conn.commit()
        conn.close()

        return redirect(url_for('manage_users'))

    c.execute("SELECT id, username, password, role FROM users WHERE id=?", (id,))
    user = c.fetchone()
    conn.close()

    return render_template('edit_user.html', user=user)


# ===========================
# PROFIL UTILIZATOR
# ===========================

@app.route("/profile")
@login_required
def profile():
    conn = sqlite3.connect("hala.db")
    c = conn.cursor()
    c.execute("SELECT id, username, role, created_at, avatar FROM users WHERE id = ?", (session["user_id"],))
    row = c.fetchone()
    conn.close()

    # fallback dacă avatarul e NULL
    avatar = row[4] if row[4] else "default.png"

    user = {
        "id": row[0],
        "username": row[1],
        "role": row[2],
        "created_at": row[3],
        "avatar": avatar
    }

    return render_template("profile.html", user=user)


# ===========================
# UPLOAD AVATAR (mutat aici)
# ===========================

@app.route("/upload_avatar", methods=["POST"])
@login_required
def upload_avatar():

    if "avatar" not in request.files:
        return "Niciun fișier încărcat!"

    file = request.files["avatar"]

    if file.filename == "":
        return "Fișier invalid!"

    filename = secure_filename(session["user"] + "_avatar.png")
    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(path)

    conn = sqlite3.connect("hala.db")
    c = conn.cursor()
    c.execute("UPDATE users SET avatar = ? WHERE username = ?", (filename, session["user"]))
    conn.commit()
    conn.close()

    return redirect(url_for("profile"))

# ===========================
# STATISTICI
# ===========================

@app.route('/stats')
@login_required
def stats():

    conn = sqlite3.connect('hala.db')
    c = conn.cursor()

    # Total materiale
    c.execute("SELECT COUNT(*) FROM materials")
    total_items = c.fetchone()[0]

    # Valoare totala – momentan 0 (daca nu ai coloana price)
    total_value = 0

    # Materiale cu stoc scazut
    c.execute("SELECT category, stock, unit FROM materials WHERE stock < 5")
    low_stock = [
        {"category": row[0], "stock": row[1], "unit": row[2]}
        for row in c.fetchall()
    ]

    # Distributie pe categorii
    c.execute("""
        SELECT category, COUNT(*) 
        FROM materials 
        GROUP BY category
    """)
    rows = c.fetchall()
    category_labels = [r[0] for r in rows]
    category_values = [r[1] for r in rows]

    conn.close()

    return render_template(
        'stats.html',
        total_items=total_items,
        total_value=total_value,
        low_stock=low_stock,
        category_labels=category_labels,
        category_values=category_values
    )

# ===========================
# RAPOARTE
# ===========================

@app.route('/rapoarte')
def rapoarte():
    return render_template('rapoarte.html')

@app.route("/reports")
@login_required
def reports():

    conn = sqlite3.connect("hala.db")
    c = conn.cursor()

    if session["role"] == "admin":
        c.execute("SELECT * FROM reports ORDER BY date DESC")
    else:
        c.execute("SELECT * FROM reports WHERE user_id = ? ORDER BY date DESC", (session["user_id"],))

    rows = c.fetchall()
    conn.close()

    reports = [
        {
            "id": r[0],
            "user_id": r[1],
            "username": r[2],
            "date": r[3],
            "start_hour": r[4],
            "end_hour": r[5],
            "location": r[6],
            "description": r[7],
            "created_at": r[8],
        }
        for r in rows
    ]

    return render_template("reports.html", reports=reports, role=session["role"])


@app.route("/reports/new", methods=["GET", "POST"])
@login_required
def new_report():

    if request.method == "POST":
        date = request.form["date"]
        start_hour = request.form["start_hour"]
        end_hour = request.form["end_hour"]
        location = request.form["location"]
        description = request.form["description"]

        conn = sqlite3.connect("hala.db")
        c = conn.cursor()

        c.execute("""
            INSERT INTO reports (user_id, username, date, start_hour, end_hour, location, description)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (session["user_id"], session["user"], date, start_hour, end_hour, location, description))

        conn.commit()
        conn.close()

        return redirect("/reports")

    return render_template("report_new.html")


@app.route("/reports/<int:id>")
@login_required
def view_report(id):

    conn = sqlite3.connect("hala.db")
    c = conn.cursor()
    c.execute("SELECT * FROM reports WHERE id = ?", (id,))
    r = c.fetchone()
    conn.close()

    if not r:
        return "Raport inexistent!"

    report = {
        "id": r[0],
        "user_id": r[1],
        "username": r[2],
        "date": r[3],
        "start_hour": r[4],
        "end_hour": r[5],
        "location": r[6],
        "description": r[7],
        "created_at": r[8]
    }

    return render_template("report_view.html", report=report, role=session["role"])


@app.route("/reports/<int:id>/edit", methods=["GET", "POST"])
@login_required
def edit_report(id):

    conn = sqlite3.connect("hala.db")
    c = conn.cursor()
    c.execute("SELECT * FROM reports WHERE id = ?", (id,))
    r = c.fetchone()

    if not r:
        return "Raport inexistent!"

    if session["role"] != "admin" and r[1] != session["user_id"]:
        return "Nu ai dreptul sa editezi acest raport!", 403

    if request.method == "POST":
        date = request.form["date"]
        start_hour = request.form["start_hour"]
        end_hour = request.form["end_hour"]
        location = request.form["location"]
        description = request.form["description"]

        c.execute("""
            UPDATE reports
            SET date=?, start_hour=?, end_hour=?, location=?, description=?
            WHERE id=?
        """, (date, start_hour, end_hour, location, description, id))

        conn.commit()
        conn.close()

        return redirect("/reports")

    report = {
        "id": r[0],
        "user_id": r[1],
        "username": r[2],
        "date": r[3],
        "start_hour": r[4],
        "end_hour": r[5],
        "location": r[6],
        "description": r[7]
    }

    conn.close()
    return render_template("report_edit.html", report=report)


@app.route("/reports/<int:id>/delete")
@login_required
@role_required("admin")
def delete_report(id):

    conn = sqlite3.connect("hala.db")
    c = conn.cursor()
    c.execute("DELETE FROM reports WHERE id = ?", (id,))
    conn.commit()
    conn.close()

    return redirect("/reports")

# ===========================
# SCHIMBARE PAROLĂ
# ===========================

@app.route('/change_password', methods=['POST'])
@login_required
def change_password():

    new_password = request.form.get("new_password")
    confirm = request.form.get("confirm_password")

    if new_password != confirm:
        return "Parolele nu coincid!"

    update_user_password(session["user_id"], new_password)

    return redirect(url_for('profile'))


def update_user_password(user_id, new_password):
    conn = sqlite3.connect('hala.db')
    c = conn.cursor()
    c.execute("UPDATE users SET password = ? WHERE id = ?", (new_password, user_id))
    conn.commit()
    conn.close()


# ===========================
# LOGOUT
# ===========================

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# ===========================
# PORNIRE SERVER
# ===========================

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)