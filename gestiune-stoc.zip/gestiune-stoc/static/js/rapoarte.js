// Rol utilizator preluat din Flask
let isAdmin = document.body.dataset.role === "admin";

// Incarcam rapoarte salvate
let reports = JSON.parse(localStorage.getItem("rapoarte")) || [];

const reportList = document.getElementById("reportList");
const modal = document.getElementById("reportModal");
const modalTitle = document.getElementById("modalTitle");

const operatorInput = document.getElementById("operatorName");
const dateInput = document.getElementById("reportDate");
const timeInInput = document.getElementById("timeIn");
const timeOutInput = document.getElementById("timeOut");
const locationInput = document.getElementById("location");
const descInput = document.getElementById("workDescription");

let editIndex = null;

// DESCHIDE MODAL
document.getElementById("newReportBtn").addEventListener("click", () => {
    modal.classList.remove("hidden");
    modalTitle.textContent = "Raport Nou";
    editIndex = null;

    operatorInput.value = "";
    dateInput.value = "";
    timeInInput.value = "";
    timeOutInput.value = "";
    locationInput.value = "";
    descInput.value = "";
});

// INCHIDE MODAL
document.getElementById("cancelBtn").addEventListener("click", () => {
    modal.classList.add("hidden");
});

// SALVEAZA RAPORT
document.getElementById("saveReportBtn").addEventListener("click", () => {
    const newReport = {
        operator: operatorInput.value,
        date: dateInput.value,
        timeIn: timeInInput.value,
        timeOut: timeOutInput.value,
        location: locationInput.value,
        work: descInput.value
    };

    if (editIndex === null) {
        reports.push(newReport);
    } else {
        reports[editIndex] = newReport;
    }

    localStorage.setItem("rapoarte", JSON.stringify(reports));
    modal.classList.add("hidden");
    renderReports();
});

// AFISEAZA RAPOARTE
function renderReports() {
    reportList.innerHTML = "";

    reports.forEach((r, index) => {
        const card = document.createElement("div");
        card.classList.add("report-card");

        card.innerHTML = `
            <h3>${r.operator} – ${r.date}</h3>
            <p><strong>Intrare:</strong> ${r.timeIn}</p>
            <p><strong>Iesire:</strong> ${r.timeOut}</p>
            <p><strong>Locatie:</strong> ${r.location}</p>
            <p><strong>Activitate:</strong> ${r.work}</p>

            <div class="card-actions">
                <button class="edit-btn" onclick="editReport(${index})">Editeaza</button>
                ${
                    isAdmin
                    ? `<button class="delete-btn" onclick="deleteReport(${index})">Sterge</button>`
                    : ``
                }
            </div>
        `;

        reportList.appendChild(card);
    });
}

renderReports();

// EDITARE
window.editReport = function(index) {
    modal.classList.remove("hidden");
    modalTitle.textContent = "Editeaza Raport";
    editIndex = index;

    const r = reports[index];

    operatorInput.value = r.operator;
    dateInput.value = r.date;
    timeInInput.value = r.timeIn;
    timeOutInput.value = r.timeOut;
    locationInput.value = r.location;
    descInput.value = r.work;
};

// STERGERE - doar admin
window.deleteReport = function(index) {
    if (!isAdmin) {
        alert("Doar admin-ul poate sterge rapoarte!");
        return;
    }

    if (confirm("Stergi raportul?")) {
        reports.splice(index, 1);
        localStorage.setItem("rapoarte", JSON.stringify(reports));
        renderReports();
    }
};
