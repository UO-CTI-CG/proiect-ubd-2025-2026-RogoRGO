// Example JS logic for statistics page
document.addEventListener("DOMContentLoaded", () => {

    // Example updates for statistics values
    const totalProducts = document.getElementById("statTotalProducts");
    const lowStock = document.getElementById("statLowStock");
    const soldToday = document.getElementById("statSoldToday");

    // You would normally fetch these from backend
    totalProducts.textContent = "128";
    lowStock.textContent = "7";
    soldToday.textContent = "34";

    // Chart example (using Chart.js)
    const ctx = document.getElementById("salesChart");
    if (ctx) {
        new Chart(ctx, {
            type: "bar",
            data: {
                labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                datasets: [{
                    label: "Sales",
                    data: [12, 19, 3, 5, 2, 3, 9]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
});
