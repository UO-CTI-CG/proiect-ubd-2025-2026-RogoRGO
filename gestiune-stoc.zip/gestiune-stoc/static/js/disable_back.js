window.onload = function () {
    // Curata istoricul imediat dupa incarcare
    if (window.history && window.history.pushState) {
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () {
            window.history.go(1);
        };
    }

    // Forteaza reincarcarea completa a paginii cand userul incearca back
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) {
            window.location.reload();
        }
    });

    // Sterge cache-ul si cookies-urile
    sessionStorage.clear();
    localStorage.clear("rapoarte", JSON.stringify(reports));

    // Pentru siguranta, curata si formularele
    const forms = document.querySelectorAll("form");
    forms.forEach(f => f.reset());
};