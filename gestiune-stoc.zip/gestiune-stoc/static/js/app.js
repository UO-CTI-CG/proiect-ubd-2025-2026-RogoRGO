console.log("Frontend JS Incarcat.");

const searchCategory = document.getElementById('searchCategory');
const searchFinish = document.getElementById('searchFinish');
const searchColor = document.getElementById('searchColor');
const searchThickness = document.getElementById('searchThickness');
const table = document.getElementById('materialsTable').getElementsByTagName('tbody')[0];

function filterTable() {
    const categoryFilter = searchCategory.value.toLowerCase();
    const finishFilter = searchFinish.value.toLowerCase();
    const colorFilter = searchColor.value.toLowerCase();
    const thicknessFilter = searchThickness.value.toLowerCase();

    for (let row of table.rows) {
        const category = row.cells[1].textContent.toLowerCase();
        const finish = row.cells[2].textContent.toLowerCase();
        const color = row.cells[3].textContent.toLowerCase();
        const thickness = row.cells[4].textContent.toLowerCase();

        if (category.includes(categoryFilter) &&
            finish.includes(finishFilter) &&
            color.includes(colorFilter) &&
            thickness.includes(thicknessFilter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    }
}

searchCategory.addEventListener('keyup', filterTable);
searchFinish.addEventListener('keyup', filterTable);
searchColor.addEventListener('keyup', filterTable);
searchThickness.addEventListener('keyup', filterTable);