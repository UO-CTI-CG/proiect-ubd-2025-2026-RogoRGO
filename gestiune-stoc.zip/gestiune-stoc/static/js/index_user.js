function toggleUserMenu() {
    const dropdown = document.getElementById("user-dropdown");
    dropdown.classList.toggle("hidden");
}

// Inchide meniul daca dai click in afara lui
document.addEventListener("click", function(e) {
    const icon = document.querySelector(".user-icon");
    const menu = document.getElementById("user-dropdown");

    if (!icon.contains(e.target) && !menu.contains(e.target)) {
        menu.classList.add("hidden");
    }
});

function toggleUserMenu() {
    document.getElementById("user-dropdown").classList.toggle("hidden");
}

function toggleSideMenu() {
    document.getElementById("side-menu").classList.toggle("hidden");
}