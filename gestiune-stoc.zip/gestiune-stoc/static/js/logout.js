window.history.pushState(null, "", window.location.href);
window.onpopstate = function () {
    window.history.pushState(null, "", window.location.href);
};

// Curata datele salvate
sessionStorage.clear();
localStorage.clear("rapoarte", JSON.stringify(reports));