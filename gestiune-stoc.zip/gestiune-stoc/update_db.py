import sqlite3

conn = sqlite3.connect("hala.db")
c = conn.cursor()

# Verificam daca exista coloana "avatar"
c.execute("PRAGMA table_info(users)")
columns = [col[1] for col in c.fetchall()]

if "avatar" not in columns:
    c.execute("ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT 'default.png'")
    print("Coloana 'avatar' a fost adaugata!")
else:
    print("Coloana 'avatar' exista deja, nu o mai adaug!")

conn.commit()
conn.close()